﻿
namespace FootballManager.ViewModels
{
    public class LoginViewModel  : UserWithName
    {      
        public string Password { get; set; }
    }
}
