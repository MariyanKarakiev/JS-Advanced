﻿using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> heroes)
        {
            int deadKnights = 0;
            int deadBarbarians = 0;

            var knights = heroes.Where(h => h.GetType().Name == nameof(Knight)).ToList();
            var barbarians = heroes.Where(h => h.GetType().Name == nameof(Barbarian)).ToList();


            foreach (var knight in knights)
            {
                if (knight.IsAlive && knight.Weapon != null)
                {
                    foreach (var barbarian in barbarians)
                    {
                        if (barbarian.IsAlive)
                        {
                            barbarian.TakeDamage(knight.Weapon.DoDamage());
                        }
                        else
                        {
                            deadBarbarians++;
                        }
                    }
                }
                else
                {
                    deadKnights++;
                }
            }

            foreach (var barbarian in barbarians)
            {
                if (barbarian.IsAlive && barbarian.Weapon != null)
                {
                    foreach (var knight in knights)
                    {
                        if (knight.IsAlive)
                        {
                            knight.TakeDamage(barbarian.Weapon.DoDamage());
                        }
                        else
                        {
                            deadKnights++;
                        }
                    }
                }
                else
                {
                    deadBarbarians++;
                }
            }

            if (knights.Count != 0 && deadBarbarians != 0)
            {
                return $"The knights took {deadKnights} casualties but won the battle.";
            }

            else
            {
                return $"The barbarians took { deadBarbarians } casualties but won the battle.";
            }
        }
    }
}
