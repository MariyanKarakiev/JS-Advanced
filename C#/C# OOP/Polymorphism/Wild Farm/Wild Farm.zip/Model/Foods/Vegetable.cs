﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Model
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
