﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Military.Enums
{
    public enum Corps
    {
        Airforces = 0,
        Marines = 1,
    }
}
