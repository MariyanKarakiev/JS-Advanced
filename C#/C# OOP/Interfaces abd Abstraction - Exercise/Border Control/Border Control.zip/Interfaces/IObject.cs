﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control.Interfaces
{
    public interface INamable
    {
        string Name { get; }
        int Age { get; }
    }
}
