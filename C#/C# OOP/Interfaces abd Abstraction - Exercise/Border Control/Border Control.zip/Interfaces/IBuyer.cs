﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control.Interfaces
{
    public interface IBuyer
    {
        int Food { get; }
        void BuyFood();
    }
}
