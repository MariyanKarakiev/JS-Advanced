﻿namespace CarDealer
{
    internal class ImportSupplierDTO
    {
    }
}