﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data.Models.Enumerables
{
    public enum ResourceType
    {
        Video = 0,
        Presentation = 1,
        Document = 2,
        Other = 3
    }
}
