﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost,1433;Database=MusicHub;User Id=sa;Password=Docker21;TrustServerCertificate=True";
    }
}
