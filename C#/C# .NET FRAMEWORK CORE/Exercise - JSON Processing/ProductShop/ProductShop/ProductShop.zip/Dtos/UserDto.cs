﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos
{
    class UserDto
    {
        public int? Age { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
