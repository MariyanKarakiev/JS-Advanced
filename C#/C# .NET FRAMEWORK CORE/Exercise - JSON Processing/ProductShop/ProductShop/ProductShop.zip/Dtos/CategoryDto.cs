﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos
{
    class CategoryDto
    {
        public string Name { get; set; }
    }
}
