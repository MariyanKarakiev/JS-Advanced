﻿using System;
using System.Collections.Generic;

namespace BoxOfT
{
   public class StartUp
    {
        public static void Main(string[] args)
        {
          
        }
    }
}
